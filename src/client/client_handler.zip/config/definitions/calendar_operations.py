Operation = {
    "info" : "i",
    "create" : "c",
    "get" : "g",
    "update" : "u",
    "delete" : "d",
    "exit" : "e"
}